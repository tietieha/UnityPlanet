﻿using Unity.Entities;
/// <summary>
/// Empty Tag for enemies
/// </summary>
[GenerateAuthoringComponent]
public class EnemyTag : IComponentData
{
}
