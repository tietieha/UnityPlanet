﻿using Unity.Entities;
/// <summary>
/// Empty Tag for bullet Entities
/// </summary>
[GenerateAuthoringComponent]
public class BulletTag : IComponentData
{
}
